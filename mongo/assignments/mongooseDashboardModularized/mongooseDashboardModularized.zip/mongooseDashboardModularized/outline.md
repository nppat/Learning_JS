# Mongoose Dashboard Modularize#

Take mongoose dashoboard, clone it, and modularize it.
