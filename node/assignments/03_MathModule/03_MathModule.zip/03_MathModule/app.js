var mathlib = require('./mathlib');
console.log(mathlib.add(1,2));  // returns 3
console.log(mathlib.multiply(2,2));  // returns 4
console.log(mathlib.square(5));  // returns 25
console.log(mathlib.random(5,29)); // returns a random number between 5 and 29