var mongoose = require('mongoose');

console.log("Future mongoose connection and model loading");