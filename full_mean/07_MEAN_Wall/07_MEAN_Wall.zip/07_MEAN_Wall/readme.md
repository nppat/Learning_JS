# MEAN Wall #

This assignment is to build a wall that a user can make a post on, and comment on posts as well.
The user can register and login.  A cookie keeps track of whether the user is logged in or not,
and directs the user to login if they have not done so.  A user is able to comment on other user's
posts.

### Difficulties ###
- `npm install bcrypt` would not work, so I had to `npm install bcrypjs`
- learning about associations.  Have always had a problem with this for some reason. Need more practice

#### Later Improvements ####
-  Will go back through and impliment Bootstrap for styling, have just ran out of time for now.

#### Shout out to Tommy Oh for the help ####